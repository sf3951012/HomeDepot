library(dplyr)
library(xgboost)
table_CI <- read.csv("table_NumRows.csv")
table_CR <- read.csv("table_CR.csv")
bst <- xgb.load("xgboost_logistic.model")

calc_conversion <- function(department, class, subclass,Date, Image.Count, Video.Count,Super.SKU, Avg.Salient.Bullets, Collection, Coordinating, Accessory, Assembly.Doc, Specification.Doc, Use...Care.Manual, Warranty.Doc, Install.Doc, Rich.Content, Spin, Review.Count, Average.Rating, EFF_RETAIL, FY, FW, lastPermPrice, promoType, brand,priceType,table_CR,hist_conversion_rate) {
  combined_class <- paste0("V1_", department, "_", class, "_", subclass)
  CR <- table_CR[which(combined_class == table_CR$class),]
  CR_mean <- as.numeric(CR[1,3])
  CR_median <- as.numeric(CR[1,2])
  CR_mean <- ifelse(is.na(CR_mean), 0.01,CR_mean)
  CR_median <- ifelse(is.na(CR_median), 0,CR_median)
  class_matrix <- determine_class(combined_class)
  brand_matrix <- determine_brand(brand)
  promoType <- paste0("V1_",promoType)
  promoType_matrix <- determine_promoType(promoType)
  priceType <- paste0("V1_",priceType)
  priceType_matrix <- determine_priceType(priceType)
  # combine all the vector variables into a matrix
  # the order below is based on the order of variable inputs in the modelling part (xgboost)
  mat <- cbind(Date, Image.Count, Video.Count,Avg.Salient.Bullets,Super.SKU, Collection, Coordinating, Accessory, Assembly.Doc, Specification.Doc, Use...Care.Manual, Warranty.Doc, Install.Doc, Rich.Content, Spin, Review.Count, Average.Rating, EFF_RETAIL, FY, FW, lastPermPrice,CR_median,CR_mean,hist_conversion_rate,brand_matrix,class_matrix,priceType_matrix,1,0,0,0,0,promoType_matrix)
  conversion =  predict(bst,as.matrix(mat))
  return(conversion)
}

determine_brand <- function(brand){
  m <- matrix(1:148,1)                                
  brand_names <- c("V1_3-M COMPANY","V1_AMERICAN STANDARD INC","V1_ANCHOR DISTRIBUTING INC","V1_APACHE MILLS INC" ,"V1_APEX TOOL GROUP LLC","V1_APPLE FURNITURE CORPORATION","V1_ARMSTRONG FLOORING","V1_AVEN TOOLS INC", "V1_BALTA US INC","V1_BARRETTE OUTDOOR LIVING","V1_BEIJING HOME VALUE","V1_BIG ROCK SPORTS LLC","V1_BISS PRODUCT DEVELOPMENT","V1_BLACK and DECKER HHI" ,"V1_BLACK and DECKER POWER TOOLS","V1_BOISE CASCADE","V1_BON TOOL CO","V1_BROAN NUTONE LLC","V1_BSH HOME APPLIANCES CORPORATION","V1_CALCULATED INDUSTRIES","V1_CARPET ART DECO","V1_CHANNELLOCK INC","V1_CHERVON NORTH AMERICA IN","V1_CHIN-SHU WOODEN LTD" ,"V1_CLOSETMAID CORPORATION","V1_COLONIAL MILLS INC" ,"V1_COLUMBIA FOREST PRODUCTS" ,"V1_CONCORD GLOBAL TRADING INC","V1_CONTEMPORARY MARKETING GROUP","V1_CROWN BOLT", "V1_CUSTOM SERVICE HARDWARE INC","V1_D-UNIQUE TOOLS" ,"V1_DEVGIRI EXPORTS LLC","V1_DYNAMIC RUGS INC","V1_EASY HOME ORGANIZATION MANUFACTURING CO LIMITED","V1_EASY STRIKE LTD","V1_ECOMMERCE LIGHTING","V1_EDSAL MANUFACTURING CO","V1_ELECTROLUX","V1_ENGINEERED FLOORS","V1_FIBER COMPOSITES LLC","V1_FOSS MANUFACTURING CO IN" ,"V1_FRANKLIN SENSORS","V1_FUTURE FOAM INC","V1_GAF BUILDING MATERIALS","V1_GE APPLIANCES","V1_GENERAL TOOLS MFG CO LLC","V1_GENERIC HDC IMPORT","V1_GENERIC MINCRON CONV","V1_GLEASON CONSUMER PRODUCT","V1_GONG FONG ENTERPRISE","V1_GREAT NECK SAW MFG INC","V1_GREAT STAR TOOLS","V1_GREEN MOUNTAIN PRODUCT INC","V1_HALDER","V1_HALSTEAD NEW ENGLAND COR","V1_HENKEL CONSUMER ADHESIVE","V1_HOME DYNAMIX LLC","V1_HOME GARDEN HARDWARE INC","V1_HOME LEGEND","V1_HONEY CAN DO INTERNATIONAL","V1_HONGKONG GOLDEN DEER CO","V1_HUIZHOU STANDBY","V1_IMPACTO PROTECTIVE PRODUCTS","V1_INTERLINE","V1_IRON BRIDGE TOOLS INC","V1_IVC","V1_JAIPUR RUGS","V1_JEWETT-CAMERON LUMBER CO","V1_JIN RONG HUA LE METAL MANUFACTURES","V1_JOHNSON LEVEL and TOOL MFG","V1_K-TOOL INTERNATIONAL INC","V1_KAPRO TOOLS INC","V1_KAS ORIENTAL RUGS, INC","V1_KING TOOLS AND EQUIPMENT","V1_KLEIN TOOLS INC","V1_KNAPE AND VOGT","V1_KOHLER COMPANY","V1_KRAUS USA FLOORING","V1_KROY BUILDING PRODUCTS","V1_LANART RUG INC","V1_LG ELECTRONICS USA INC","V1_LINON HOME DECOR PRODUCT","V1_LL BUILDING PRODUCTS INC","V1_M-D BUILDING PRODUCTS IN","V1_MATERIALS PACKAGING CORP","V1_MCFARLAND CASCADE","V1_MENDOCINO FOREST PRODUCT","V1_MERIDIAN INTERNATIONAL CO LTD","V1_MILLENNIUM MODULAR LLC","V1_MILWAUKEE ELECTRIC TOOL","V1_MOHAWK HOME","V1_MS INTERNATIONAL INC","V1_MULTY HOME CANADA","V1_N.C. JOHN AND SONS (P) LTD","V1_NANCE INDUSTRIES","V1_NATCO PRODUCTS CORPORATI","V1_NATIONAL ELECTRONICS WARRANTY","V1_NEWAGE PRODUCTS INC","V1_NEWCORP INTERNATIONAL CO","V1_NINGBO LOYAL LIGHTING TECHNOLOGY CO LTD", "V1_NOURY and SONS LTD","V1_NOVALIS ENTERPRISES LTD","V1_OLDCASTLE APG","V1_ORIAN RUGS INC","V1_ORIENTAL WEAVERS RUG MFG","V1_OWENS-CORNING FIBERGLAS","V1_P.S.MFG.COMPANY","V1_PT INTERTREND UTAMA","V1_QEP CO INC","V1_RAPID TOOLS","V1_REV-A-SHELF INC","V1_RIZTEX USA","V1_ROBERT BOSCH TOOL CORPOR","V1_ROUTE66 INTERNATIONAL","V1_RSI HOME PRODUCTS INC","V1_RUBBERMAID HOME PRODUCTS","V1_RUGGEAR USA LLC","V1_RUST-OLEUM CORP","V1_S P RICHARDS COMPANY","V1_SAFAVIEH CARPETS","V1_SAMS GOLD IMPORTS INC","V1_SAMSUNG","V1_SANDUSKY PA","V1_SIGNATURE DEVELOPMENT IN","V1_SIGNATURE PRODUCTS GROUP","V1_SNAVELY FOREST PRODUCTS","V1_SOUTHWIRE COMPANY","V1_STANLEY TOOLS DIV","V1_SURYA CARPET INC","V1_TAPE EASE LLC","V1_TASK TOOLS AND ABRASIVES","V1_THE MARVEL GROUP INC","V1_THE PARALLAX GROUP INTERNATIONAL LLC","V1_TIGER SUPPLIES","V1_TRAVANCORE COCOTUFT (P) LTD","V1_TRIMBLE NAVIGATION LTD","V1_TURF EVOLUTIONS LLC","V1_UNIVERSAL FOREST PRODUCT","V1_VAN GELDER INC","V1_VAROUJ APPLIANCES SERVICES","V1_VENTURE CARPETS INC","V1_VINYLTECH ENTERPRISE CO LTD","V1_WELSPUN GLOBAL BRANDS LIMITED","V1_WENDENG MAXPOWER TOOL","V1_WERNER CO","V1_WHIRLPOOL CORPORATION","V1_WOODEN PARK INDUSTRIES CO")
  for (i in 1:length(brand_names)) {
    if(brand == brand_names[i]) {
      m[i][1] <- 1
    }else{
      m[i][1] <- 0
    }
  }
  return(m)
}

determine_class <- function(combined_class) {
  m <- matrix(1:192,1)
  classes_name <- c("V1_21_13_2","V1_21_13_3","V1_21_13_61","V1_21_18_2","V1_21_1_5","V1_21_1_6","V1_21_1_60","V1_21_20_2","V1_21_20_4", "V1_21_20_5","V1_21_20_6","V1_21_20_60","V1_21_20_9", "V1_21_2_6","V1_21_5_10","V1_21_5_14","V1_21_5_18","V1_21_5_19","V1_21_5_8","V1_21_5_9","V1_21_7_2","V1_21_7_4","V1_21_7_6","V1_21_7_60","V1_21_7_7","V1_21_8_11","V1_21_8_12","V1_21_8_14","V1_21_8_15", "V1_21_8_16","V1_21_8_2","V1_21_8_4","V1_21_8_5","V1_21_8_60","V1_21_8_61","V1_21_8_8","V1_21_8_9","V1_21_90_6","V1_22_10_10","V1_22_10_14","V1_22_10_17","V1_22_10_2","V1_22_10_20","V1_22_10_4","V1_22_10_60","V1_22_10_63","V1_22_12_5","V1_22_12_6","V1_22_12_7","V1_22_13_2","V1_22_13_3","V1_22_13_60","V1_22_13_9","V1_22_3_5","V1_22_3_60","V1_22_4_11","V1_22_4_2","V1_22_4_4","V1_22_4_5","V1_22_4_6","V1_22_4_60","V1_22_4_7","V1_22_4_9","V1_22_8_10","V1_22_8_11","V1_22_8_12","V1_22_8_13","V1_22_8_2","V1_22_8_3","V1_22_8_4","V1_22_8_5","V1_22_8_6","V1_22_8_7","V1_22_8_8", "V1_22_8_9","V1_22_90_6","V1_22_9_10","V1_22_9_13","V1_22_9_4","V1_22_9_8","V1_23_1_17","V1_23_1_18","V1_23_1_19","V1_23_1_20","V1_23_1_22","V1_23_1_23","V1_23_1_65","V1_23_1_66","V1_23_1_67","V1_23_2_10","V1_23_2_14","V1_23_2_18","V1_23_2_23","V1_23_2_6","V1_23_2_60","V1_23_2_61","V1_23_2_62","V1_23_2_8","V1_23_2_9","V1_23_3_10","V1_23_3_11","V1_23_3_12","V1_23_3_13","V1_23_3_15","V1_23_3_16" ,"V1_23_3_17","V1_23_3_18","V1_23_3_2","V1_23_3_4","V1_23_3_5","V1_23_3_60","V1_23_3_7","V1_23_3_8","V1_23_3_9","V1_23_4_12","V1_23_4_16","V1_23_4_18","V1_23_4_2","V1_23_4_3","V1_23_4_60","V1_23_4_62","V1_23_4_70","V1_23_4_8","V1_23_7_11","V1_23_7_13","V1_23_7_14","V1_23_7_16","V1_23_7_17","V1_23_7_2","V1_23_7_5","V1_23_7_6","V1_23_7_60","V1_23_7_8","V1_25_1_11","V1_25_1_13","V1_25_1_14","V1_25_1_16","V1_25_1_17","V1_25_1_18","V1_25_1_2","V1_25_1_4","V1_25_1_5","V1_25_1_6","V1_25_1_60","V1_25_1_7","V1_25_1_8","V1_29_13_10","V1_29_13_11","V1_29_13_12","V1_29_13_15","V1_29_13_16","V1_29_13_17","V1_29_13_18","V1_29_13_19","V1_29_13_2","V1_29_13_20","V1_29_13_3","V1_29_13_4","V1_29_13_5","V1_29_13_6","V1_29_13_60","V1_29_13_7","V1_29_13_8","V1_29_13_9","V1_29_7_2","V1_29_7_3","V1_29_7_4","V1_29_7_6","V1_29_7_8","V1_29_7_9","V1_29_8_10","V1_29_8_11","V1_29_8_12","V1_29_8_13","V1_29_8_14","V1_29_8_15","V1_29_8_16","V1_29_8_17","V1_29_8_18" ,"V1_29_8_19","V1_29_8_2","V1_29_8_20","V1_29_8_21","V1_29_8_22","V1_29_8_3","V1_29_8_4","V1_29_8_5","V1_29_8_6","V1_29_8_60","V1_29_8_7","V1_29_8_8","V1_29_8_9")  
  for (i in 1:length(classes_name)) {
    if(combined_class == classes_name[i]) {
      m[i][1] <- 1
    }else{
      m[i][1] <- 0
    }
  }
  return(m)
}

determine_promoType <- function(promoType){
  m <- matrix(1:4,1)
  promo_typenames <- c("V1_Dollar Off","V1_Fixed Retail","V1_None","V1_Percent Off")
  for (i in 1:length(promo_typenames)) {
    if(promoType == promo_typenames[i]) {
      m[i][1] <- 1
    }else{
      m[i][1] <- 0
    }
  }
  return(m)
}

determine_priceType <- function(priceType){
  m <- matrix(1:2,1)
  price_typenames <- c("V1_PERM","V1_PROMO")
  for (i in 1:length(price_typenames)) {
    if(priceType == price_typenames[i]) {
      m[i][1] <- 1
    }else{
      m[i][1] <- 0
    }
  }
  return(m)
}
